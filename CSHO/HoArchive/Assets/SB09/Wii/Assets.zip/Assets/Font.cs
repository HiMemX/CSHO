namespace SB09WiiAsset{
    public class Font : Asset.AssetEntity{
        public Font(HoArchive.MemoryStreamEndian file){
        }

        public Font(){
        }

        public override void Update(HoArchive.TOCEntry entry){
        }

        public override void Save(HoArchive.MemoryStreamEndian file){
        }
    }
}