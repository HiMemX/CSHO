namespace SB09WiiAsset{
    public class CameraD : Asset.AssetEntity{
        public CameraD(HoArchive.MemoryStreamEndian file){
        }
        public CameraD(){
        }

        public override void Update(HoArchive.TOCEntry entry){
        }

        public override void Save(HoArchive.MemoryStreamEndian file){
        }
    }
}