namespace SB09WiiAsset{
    public class ElectricArc : Asset.AssetEntity{
        public ElectricArc(HoArchive.MemoryStreamEndian file){
        }

        public ElectricArc(){
        }

        public override void Update(HoArchive.TOCEntry entry){
        }

        public override void Save(HoArchive.MemoryStreamEndian file){
        }
    }
}