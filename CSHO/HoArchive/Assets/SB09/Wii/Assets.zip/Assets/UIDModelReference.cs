namespace SB09WiiAsset{
    public class UIDModelReference : Asset.AssetEntity{
        public UIDModelReference(){
        }

        public UIDModelReference(HoArchive.MemoryStreamEndian file){
        }

        public override void Update(HoArchive.TOCEntry entry){
        }

        public override void Save(HoArchive.MemoryStreamEndian file){
        }
    }
}