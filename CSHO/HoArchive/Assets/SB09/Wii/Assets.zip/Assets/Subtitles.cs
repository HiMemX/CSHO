namespace SB09WiiAsset{
    public class Subtitles : Asset.AssetEntity{
        public Subtitles(){
        }

        public Subtitles(HoArchive.MemoryStreamEndian file){
        }

        public override void Update(HoArchive.TOCEntry entry){
        }

        public override void Save(HoArchive.MemoryStreamEndian file){
        }
    }
}