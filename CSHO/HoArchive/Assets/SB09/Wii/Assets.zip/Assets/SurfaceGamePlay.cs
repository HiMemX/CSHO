namespace SB09WiiAsset{
    public class SurfaceGamePlay : Asset.AssetEntity{
        public SurfaceGamePlay(){
        }

        public SurfaceGamePlay(HoArchive.MemoryStreamEndian file){
        }

        public override void Update(HoArchive.TOCEntry entry){
        }

        public override void Save(HoArchive.MemoryStreamEndian file){
        }
    }
}