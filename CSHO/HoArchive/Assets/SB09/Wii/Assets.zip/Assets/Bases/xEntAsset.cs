using System.ComponentModel;
using System.Numerics;
using RenderingInternal;

namespace SB09WiiAsset{
    public class xEntAsset : xBaseAsset{


        public byte flags {get; set;} = new();
        public byte subtype {get; set;} = new();
        public byte pad {get; set;} = new();
        public bool Targettable {get; set;} = new();
        public byte Pad0 {get; set;} = new();
        public byte MoreFlags {get; set;} = new();
        [TypeConverter(typeof(HoArchive.AssetIDConverter))]
        public ulong surfaceID {get; set;} = new();
        [TypeConverter(typeof(HoArchive.Point3Converter))]
        public HoArchive.float3 Orientation {get; set;} = new();
        [TypeConverter(typeof(HoArchive.Point3Converter))]
        public HoArchive.float3 Pos {get; set;} = new();
        [TypeConverter(typeof(HoArchive.Point3Converter))]
        public HoArchive.float3 Scale {get; set;} = new();
        [TypeConverter(typeof(ExpandableObjectConverter))]
        public ModelInstanceAsset modelInstance {get; set;} = new();
        [TypeConverter(typeof(HoArchive.AssetIDConverter))]
        public ulong animListID {get; set;} = new();
        [TypeConverter(typeof(ExpandableObjectConverter))]
        public PhysicsDataStruct physicsData {get; set;} = new();
        public uint Pad1 {get; set;} = new();
        public uint Pad2 {get; set;} = new();
        public uint Pad3 {get; set;} = new();

        public xEntAsset() : base() {}

        public xEntAsset(HoArchive.MemoryStreamEndian file) : base(file){
            
            flags = file.ReadByte();
            subtype = file.ReadByte();
            pad = file.ReadByte();
            Targettable = file.ReadBool();
            Pad0 = file.ReadByte();
            MoreFlags = file.ReadByte();
            file.Align(0x8);
            surfaceID = file.ReadUInt64E();
            Orientation = new HoArchive.float3(file);
            Pos = new HoArchive.float3(file);
            Scale = new HoArchive.float3(file);
            file.Align(0x10);
            modelInstance = new ModelInstanceAsset(file);
            animListID = file.ReadUInt64E();
            physicsData = new PhysicsDataStruct(file);
            Pad1 = file.ReadUInt32E();
            Pad2 = file.ReadUInt32E();
            Pad3 = file.ReadUInt32E();
            
        }

        public override void Update(HoArchive.TOCEntry entry){
            base.Update(entry);

            modelInstance.Update(entry);
            physicsData.Update(entry);
        }

        public override void Save(HoArchive.MemoryStreamEndian file){
            base.Save(file);

            file.WriteE(flags);
            file.WriteE(subtype);
            file.WriteE(pad);
            file.WriteE(Targettable);
            file.WriteE(Pad0);
            file.WriteE(MoreFlags);
            file.PadAlign(0x08, 0x00);
            file.WriteE(surfaceID);
            Orientation.Save(file);
            Pos.Save(file);
            Scale.Save(file);
            file.PadAlign(0x10, 0x00);
            modelInstance.Save(file);
            file.WriteE(animListID);
            physicsData.Save(file);
            file.WriteE(Pad1);
            file.WriteE(Pad2);
            file.WriteE(Pad3);
        }

        public void SaveHeap(HoArchive.MemoryStreamEndian file){
            modelInstance.SaveHeap(file);
            physicsData.SaveHeap(file);
        }

        public ulong GetModelID()
        {
            return modelInstance.modelPrototypeID;
        }

        public Matrix4x4 GetInstanceMatrix()
        {
            Matrix4x4 scalemat =  Matrix4x4.CreateScale(new Vector3(Scale.x, Scale.y, Scale.z));
            Matrix4x4 posmat = Matrix4x4.CreateTranslation(new Vector3(Pos.x, Pos.y, Pos.z));
            Matrix4x4 rotmat = Matrix4x4.CreateFromYawPitchRoll(Orientation.x, Orientation.y, Orientation.z);

            return (scalemat * rotmat) * posmat;
        }

        public Vector3 GetPosition()
        {
            return new Vector3(Pos.x, Pos.y, Pos.z);
        }

        public void SetPosition(Vector3 newpos)
        {
            Pos = new HoArchive.float3(newpos);
        }
    }
}