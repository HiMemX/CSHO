using System.ComponentModel;
using System.Numerics;
using Asset;

namespace SB09WiiAsset{
    public class xBaseAsset : AssetEntity{
        [TypeConverter(typeof(HoArchive.AssetIDConverter))]
        public ulong id {get; set;} = new();
        [TypeConverter(typeof(HoArchive.wmlTypeIDConverter))]
        public HoArchive.wmlTypeID baseType {get; set;}  = new();
        public ushort linkCount {get; set;} = new();
        public ushort baseFlags {get; set;} = new();

        public xBaseAsset(){}

        public xBaseAsset(HoArchive.MemoryStreamEndian file){
            id = file.ReadUInt64E();
            baseType = (HoArchive.wmlTypeID)file.ReadUInt32E();
            linkCount = file.ReadUInt16E();
            baseFlags = file.ReadUInt16E();
        }

        public override void Update(HoArchive.TOCEntry entry){
            base.Update(entry);

            id = entry.uidSelf;
            baseType = entry.wmlTypeID;
        }

        public override void Save(HoArchive.MemoryStreamEndian file){
            file.WriteE(id);
            file.WriteE((uint)baseType);
            file.WriteE(linkCount);
            file.WriteE(baseFlags);
        }

        
    }
}